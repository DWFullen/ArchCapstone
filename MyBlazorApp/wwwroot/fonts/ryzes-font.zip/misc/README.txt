By installing or using this font, you are agree to the Product Usage Agreement:
- IF YOU USE THIS FONT FOR COMMERCIAL PROJECT WITHOUT BUYING OR GET PERMISSION FROM THE AUTHOR,  YOU WILL BE FINED BY HAVING TO PURCHASE THIS FONT FOR THE PRICE OF THE EXTENDED LICENSE!
- This demo font is ONLY FOR PERSONAL USE. NO COMMERCIAL USE ALLOWED! 
- Here is the link to purchase full version and commercial license: https://faptype.com/product/ryzes-cyber-graffiti-font-vol-4/?v=659bb4967f1a
- For more awesome fonts!: https://faptype.com/
- For Corporate use you have to purchase Corporate license please contact us: at ardana619@gmail.com or visit our website: https://faptype.com/
- If you need a custom license please contact us: at ardana619@gmail.com
- Any donation are very appreciated. Paypal account for donation: https://paypal.me/bpkedypurwanto
- Follow our instagram for update : @ardana619
